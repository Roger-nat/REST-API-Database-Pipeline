-- =============================================================
-- analysis.sql
-- Analytical queries for the crypto_prices table.
-- Run with: mysql -u root -p crypto_pipeline < sql/analysis.sql
-- =============================================================

USE crypto_pipeline;

-- 1. Count total records collected so far
SELECT COUNT(*) AS total_records
FROM crypto_prices;

-- 2. Minimum and maximum price ever recorded, per coin
SELECT
    symbol,
    name,
    MIN(current_price) AS min_price,
    MAX(current_price) AS max_price
FROM crypto_prices
GROUP BY symbol, name
ORDER BY max_price DESC;

-- 3. Average price and average 24h change, per coin
SELECT
    symbol,
    name,
    ROUND(AVG(current_price), 4)            AS avg_price,
    ROUND(AVG(price_change_pct_24h), 2)     AS avg_24h_change_pct
FROM crypto_prices
GROUP BY symbol, name
ORDER BY avg_price DESC;

-- 4. Group coins into market-cap tiers (simple bucketing / categorization)
SELECT
    CASE
        WHEN market_cap_rank <= 5  THEN 'Top 5'
        WHEN market_cap_rank <= 10 THEN 'Top 6-10'
        WHEN market_cap_rank <= 25 THEN 'Top 11-25'
        ELSE 'Below 25'
    END AS market_cap_tier,
    COUNT(*)                       AS num_snapshots,
    ROUND(AVG(current_price), 2)   AS avg_price_in_tier
FROM crypto_prices
GROUP BY market_cap_tier
ORDER BY MIN(market_cap_rank);

-- 5. Trend: which coins gained the most / lost the most in the last 24h
--    (based on the most recent snapshot of each coin)
SELECT
    symbol,
    name,
    current_price,
    price_change_pct_24h,
    last_updated
FROM crypto_prices cp
WHERE collected_at = (
    SELECT MAX(collected_at) FROM crypto_prices
)
ORDER BY price_change_pct_24h DESC
LIMIT 5;                                   -- top 5 gainers

-- (flip ORDER BY to ASC for top losers)

-- 6. Latest record overall (most recently collected row)
SELECT *
FROM crypto_prices
ORDER BY collected_at DESC
LIMIT 1;

-- 7. Latest snapshot for every coin (most recent row per coin_id)
SELECT cp.*
FROM crypto_prices cp
INNER JOIN (
    SELECT coin_id, MAX(collected_at) AS latest_collected_at
    FROM crypto_prices
    GROUP BY coin_id
) latest
    ON cp.coin_id = latest.coin_id
   AND cp.collected_at = latest.latest_collected_at
ORDER BY cp.market_cap_rank;

-- 8. Simple analytical report: one row per coin summarizing everything
SELECT
    symbol,
    name,
    COUNT(*)                                AS times_collected,
    ROUND(MIN(current_price), 4)            AS lowest_price_seen,
    ROUND(MAX(current_price), 4)            AS highest_price_seen,
    ROUND(AVG(current_price), 4)            AS average_price,
    ROUND(AVG(price_change_pct_24h), 2)     AS avg_24h_change_pct,
    MAX(collected_at)                       AS last_collected
FROM crypto_prices
GROUP BY symbol, name
ORDER BY average_price DESC;

-- 9. Market cap ranking snapshot as of the latest collection run
SELECT
    market_cap_rank,
    symbol,
    name,
    current_price,
    market_cap,
    total_volume
FROM crypto_prices
WHERE collected_at = (SELECT MAX(collected_at) FROM crypto_prices)
ORDER BY market_cap_rank;
