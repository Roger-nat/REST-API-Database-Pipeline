"""
REST API to Database Data Pipeline
-----------------------------------
A small ETL pipeline that:
    1. EXTRACTS  live cryptocurrency market data from the public CoinGecko REST API
    2. TRANSFORMS it with pandas (cleaning, validation, standardization)
    3. LOADS      the clean records into a MySQL table

Run:
    python src/pipeline.py

Author: <your name>
"""

import sys
import os
import json
import logging
from datetime import datetime, timezone

import requests
import pandas as pd
import mysql.connector
from mysql.connector import Error as MySQLError

# Allow importing config/config.py when running this file directly from src/
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "config"))

try:
    from config import DB_CONFIG, API_CONFIG
except ImportError:
    print(
        "ERROR: config/config.py not found.\n"
        "Copy config/config.example.py to config/config.py and fill in "
        "your MySQL credentials before running this script."
    )
    sys.exit(1)

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("pipeline")

# Fields we actually want to keep from the (much larger) API response
REQUIRED_FIELDS = [
    "id",
    "symbol",
    "name",
    "current_price",
    "market_cap",
    "market_cap_rank",
    "total_volume",
    "high_24h",
    "low_24h",
    "price_change_percentage_24h",
    "last_updated",
]


# ---------------------------------------------------------------------------
# 1. EXTRACT
# ---------------------------------------------------------------------------
def extract_data() -> list:
    """
    Calls the CoinGecko REST API and returns the raw JSON payload (a list of
    coin dicts). Raises a RuntimeError with a clear message on any failure
    so the caller can decide what to do next.
    """
    url = API_CONFIG["base_url"]
    params = API_CONFIG["params"]
    timeout = API_CONFIG["timeout_seconds"]

    log.info("Requesting data from %s", url)

    try:
        response = requests.get(url, params=params, timeout=timeout)
    except requests.exceptions.ConnectionError as exc:
        raise RuntimeError(f"API unavailable / network error: {exc}") from exc
    except requests.exceptions.Timeout as exc:
        raise RuntimeError(f"API request timed out: {exc}") from exc
    except requests.exceptions.RequestException as exc:
        raise RuntimeError(f"Unexpected request error: {exc}") from exc

    # Raise an exception for 4xx / 5xx responses
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError as exc:
        raise RuntimeError(
            f"HTTP error {response.status_code} from API: {exc}"
        ) from exc

    try:
        data = response.json()
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"API did not return valid JSON: {exc}") from exc

    if not isinstance(data, list) or len(data) == 0:
        raise RuntimeError("API returned an empty or unexpected payload.")

    log.info("Received %d records from API", len(data))
    return data


# ---------------------------------------------------------------------------
# 2. TRANSFORM
# ---------------------------------------------------------------------------
def transform_data(raw_records: list) -> pd.DataFrame:
    """
    Converts raw JSON records into a clean, validated pandas DataFrame:
        - keeps only required fields
        - handles missing fields/values
        - fixes data types
        - standardizes text fields
        - adds a collection timestamp
    """
    cleaned_rows = []

    for record in raw_records:
        row = {}
        skip_record = False

        for field in REQUIRED_FIELDS:
            value = record.get(field)  # .get() -> None if field is missing

            if value is None:
                # id/symbol/name are essential identifiers - drop the record
                # if any of them are missing. Numeric fields can default to 0.
                if field in ("id", "symbol", "name"):
                    log.warning(
                        "Dropping record missing required field '%s': %s",
                        field,
                        record.get("id", "unknown"),
                    )
                    skip_record = True
                    break
                elif field == "last_updated":
                    value = datetime.now(timezone.utc).isoformat()
                else:
                    value = 0.0  # sensible default for missing numeric fields

            row[field] = value

        if skip_record:
            continue

        cleaned_rows.append(row)

    if not cleaned_rows:
        raise RuntimeError("No valid records survived cleaning/validation.")

    df = pd.DataFrame(cleaned_rows)

    # --- Data type validation / enforcement -------------------------------
    numeric_cols = [
        "current_price",
        "market_cap",
        "market_cap_rank",
        "total_volume",
        "high_24h",
        "low_24h",
        "price_change_percentage_24h",
    ]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

    # market_cap_rank is conceptually an integer
    df["market_cap_rank"] = df["market_cap_rank"].astype(int)

    # --- Standardization ----------------------------------------------------
    df["symbol"] = df["symbol"].str.upper().str.strip()
    df["name"] = df["name"].str.strip()
    df["id"] = df["id"].str.strip()

    # Parse the API's own "last_updated" timestamp into a proper datetime
    df["last_updated"] = pd.to_datetime(df["last_updated"], errors="coerce", utc=True)
    df["last_updated"] = df["last_updated"].fillna(pd.Timestamp.now(tz="UTC"))

    # Add our own "when did WE collect this" timestamp (important for ETL
    # auditing - the API's timestamp and our collection time can differ).
    df["collected_at"] = datetime.now(timezone.utc)

    # Drop exact duplicate coin ids, keep the first occurrence
    before = len(df)
    df = df.drop_duplicates(subset="id", keep="first").reset_index(drop=True)
    if len(df) < before:
        log.warning("Dropped %d duplicate record(s)", before - len(df))

    log.info("Transformed data into DataFrame with %d rows", len(df))
    return df


# ---------------------------------------------------------------------------
# 3. LOAD
# ---------------------------------------------------------------------------
def get_db_connection():
    """Opens and returns a MySQL connection, or raises RuntimeError."""
    try:
        conn = mysql.connector.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            port=DB_CONFIG.get("port", 3306),
        )
        return conn
    except MySQLError as exc:
        raise RuntimeError(f"Could not connect to MySQL server: {exc}") from exc


def setup_database_and_table(conn):
    """Creates the database and table if they do not already exist."""
    db_name = DB_CONFIG["database"]
    cursor = conn.cursor()
    try:
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        cursor.execute(f"USE {db_name}")

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS crypto_prices (
                record_id           INT AUTO_INCREMENT PRIMARY KEY,
                coin_id             VARCHAR(100)   NOT NULL,
                symbol              VARCHAR(20)    NOT NULL,
                name                VARCHAR(100)   NOT NULL,
                current_price       DECIMAL(20, 8) NOT NULL,
                market_cap          DECIMAL(25, 2) NOT NULL,
                market_cap_rank     INT            NOT NULL,
                total_volume        DECIMAL(25, 2) NOT NULL,
                high_24h            DECIMAL(20, 8) NOT NULL,
                low_24h             DECIMAL(20, 8) NOT NULL,
                price_change_pct_24h DECIMAL(10, 4) NOT NULL,
                last_updated        DATETIME       NOT NULL,
                collected_at        DATETIME       NOT NULL,
                UNIQUE KEY uniq_coin_snapshot (coin_id, collected_at)
            )
            """
        )
        conn.commit()
        log.info("Database '%s' and table 'crypto_prices' are ready", db_name)
    except MySQLError as exc:
        raise RuntimeError(f"Failed to create database/table: {exc}") from exc
    finally:
        cursor.close()


def load_data(conn, df: pd.DataFrame):
    """Inserts the transformed DataFrame rows into MySQL."""
    cursor = conn.cursor()
    insert_sql = """
        INSERT INTO crypto_prices (
            coin_id, symbol, name, current_price, market_cap, market_cap_rank,
            total_volume, high_24h, low_24h, price_change_pct_24h,
            last_updated, collected_at
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    records = [
        (
            row["id"],
            row["symbol"],
            row["name"],
            float(row["current_price"]),
            float(row["market_cap"]),
            int(row["market_cap_rank"]),
            float(row["total_volume"]),
            float(row["high_24h"]),
            float(row["low_24h"]),
            float(row["price_change_percentage_24h"]),
            row["last_updated"].strftime("%Y-%m-%d %H:%M:%S"),
            row["collected_at"].strftime("%Y-%m-%d %H:%M:%S"),
        )
        for _, row in df.iterrows()
    ]

    try:
        cursor.executemany(insert_sql, records)
        conn.commit()
        log.info("Inserted %d record(s) into crypto_prices", cursor.rowcount)
    except MySQLError as exc:
        conn.rollback()
        raise RuntimeError(f"Failed to insert records: {exc}") from exc
    finally:
        cursor.close()


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
def run_pipeline():
    log.info("=== Pipeline started ===")

    # --- Extract ---
    try:
        raw_data = extract_data()
    except RuntimeError as exc:
        log.error("EXTRACT step failed: %s", exc)
        return

    # --- Transform ---
    try:
        df = transform_data(raw_data)
    except RuntimeError as exc:
        log.error("TRANSFORM step failed: %s", exc)
        return

    # --- Load ---
    conn = None
    try:
        conn = get_db_connection()
        setup_database_and_table(conn)
        conn.database = DB_CONFIG["database"]
        load_data(conn, df)
    except RuntimeError as exc:
        log.error("LOAD step failed: %s", exc)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
            log.info("MySQL connection closed")

    log.info("=== Pipeline finished ===")


if __name__ == "__main__":
    run_pipeline()
