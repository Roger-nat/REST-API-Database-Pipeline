"""
Example configuration file.

Copy this file to `config.py` in the same folder and fill in your own
local MySQL credentials. `config.py` should NEVER be committed to git
or shared publicly (add it to .gitignore).

    cp config/config.example.py config/config.py
"""

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_mysql_password_here",   # <-- put your real password only in config.py
    "database": "crypto_pipeline",
    "port": 3306,
}

# Public CoinGecko endpoint - no API key required.
API_CONFIG = {
    "base_url": "https://api.coingecko.com/api/v3/coins/markets",
    "params": {
        "vs_currency": "usd",
        "order": "market_cap_desc",
        "per_page": 25,
        "page": 1,
        "price_change_percentage": "24h",
    },
    "timeout_seconds": 10,
}
