# REST API to Database Data Pipeline

A small, fresher-friendly ETL project that pulls live cryptocurrency market
data from a public REST API, cleans and validates it with pandas, loads it
into MySQL, and analyzes it with SQL.

```
REST API (CoinGecko)
   ↓  Python requests (HTTP GET)
JSON Response
   ↓  validation
Data Validation
   ↓  pandas
Data Transformation
   ↓  mysql-connector
MySQL
   ↓
SQL Analysis
```

---

## 1. Why CoinGecko?

The project uses the **CoinGecko `/coins/markets` endpoint**:

```
https://api.coingecko.com/api/v3/coins/markets
```

Reasons it's the easiest reliable choice for this project:

- **No API key / authentication required** for this endpoint — one less
  thing to configure or accidentally leak.
- **Free and high rate limits** for casual/demo use.
- Returns a **rich JSON payload** (price, market cap, volume, 24h change,
  rank) — enough fields to demonstrate real transformation and validation
  logic, not just "insert one number."
- **Numeric, well-structured data** — perfect for SQL aggregation queries
  (MIN/MAX/AVG/GROUP BY), unlike free weather APIs which often require a
  key or return sparser data, or exchange-rate APIs which have fewer
  interesting fields to work with.
- Data changes constantly, so re-running the pipeline always produces
  fresh, meaningfully different rows — good for demonstrating a **repeatable
  pipeline / trend analysis** in an interview.

---

## 2. Project Structure

```
api-database-pipeline/
│
├── src/
│   └── pipeline.py          # Extract -> Transform -> Load logic
│
├── sql/
│   └── analysis.sql         # Analytical SQL queries
│
├── config/
│   └── config.example.py    # Template config (safe to commit)
│   └── config.py            # Your real credentials (git-ignored, NOT committed)
│
├── requirements.txt
└── README.md
```

---

## 3. Setup Instructions

### Prerequisites
- Python 3.9+
- MySQL Server installed and running locally (MySQL Workbench or CLI access)
- Internet access (to call the public API)

### Steps

1. **Clone / copy the project folder**, then move into it:
   ```bash
   cd api-database-pipeline
   ```

2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Create your local config file**
   ```bash
   cp config/config.example.py config/config.py
   ```
   Open `config/config.py` and fill in your real MySQL username/password.
   This file is **never committed** (add it to `.gitignore`) so no secrets
   are exposed.

5. **Make sure MySQL is running**, then just run the pipeline — it creates
   the database and table automatically on first run:
   ```bash
   python src/pipeline.py
   ```

6. **Run it again a few times** (e.g., a few minutes apart) so you get
   multiple snapshots in the table — this makes the trend/aggregate SQL
   queries much more interesting to show off.

7. **Run the analysis queries**
   ```bash
   mysql -u root -p crypto_pipeline < sql/analysis.sql
   ```
   or just open `sql/analysis.sql` in MySQL Workbench and run each query.

### `.gitignore` (recommended)
```
config/config.py
venv/
__pycache__/
```

---

## 4. Database Schema

**Database:** `crypto_pipeline`
**Table:** `crypto_prices`

| Column                | Type            | Notes                                   |
|------------------------|-----------------|------------------------------------------|
| record_id              | INT, PK, AUTO_INCREMENT | Unique row id                     |
| coin_id                | VARCHAR(100)    | CoinGecko's internal coin id (e.g. `bitcoin`) |
| symbol                 | VARCHAR(20)     | e.g. `BTC` (standardized to uppercase)  |
| name                   | VARCHAR(100)    | e.g. `Bitcoin`                          |
| current_price          | DECIMAL(20,8)   | Price in USD                            |
| market_cap             | DECIMAL(25,2)   | Market capitalization in USD            |
| market_cap_rank        | INT             | Rank among all coins                    |
| total_volume           | DECIMAL(25,2)   | 24h trading volume                      |
| high_24h                | DECIMAL(20,8)   | 24h high price                          |
| low_24h                 | DECIMAL(20,8)   | 24h low price                           |
| price_change_pct_24h    | DECIMAL(10,4)   | % price change in the last 24h          |
| last_updated            | DATETIME        | Timestamp from the API itself           |
| collected_at            | DATETIME        | Timestamp when **our pipeline** pulled the data |

`UNIQUE KEY (coin_id, collected_at)` prevents inserting an exact duplicate
snapshot if the pipeline is accidentally run twice in the same second.

---

## 5. SQL Queries (see `sql/analysis.sql`)

The file includes queries for:
1. Total record count
2. Min/max price per coin
3. Average price and average 24h % change per coin
4. Grouping coins into market-cap tiers (Top 5 / Top 6-10 / etc.)
5. Trend detection — top gainers/losers in the latest snapshot
6. The single most recent record collected
7. The latest snapshot per coin (using a self-join on `MAX(collected_at)`)
8. A full summary "report" query (count, min, max, avg per coin)
9. A market-cap ranking snapshot

---

## 6. Data Flow Explanation

1. **Extract** (`extract_data`) — Sends an HTTP GET request to the
   CoinGecko REST API using `requests`, with a timeout. Handles connection
   errors, timeouts, non-2xx HTTP status codes, and invalid JSON, raising a
   clear `RuntimeError` for each failure type.

2. **Transform** (`transform_data`) —
   - Extracts only the fields the project actually needs (`REQUIRED_FIELDS`)
     instead of storing the entire raw payload.
   - Handles missing fields: drops a record if an essential identifier
     (id/symbol/name) is missing; fills numeric fields with a safe default
     if missing.
   - Loads everything into a **pandas DataFrame**.
   - Validates/enforces data types (`pd.to_numeric`, `astype(int)`).
   - Standardizes text (symbol uppercased, whitespace stripped).
   - Parses and validates the timestamp field, and adds a second
     `collected_at` timestamp marking when **our pipeline** ran (distinct
     from the API's own `last_updated`) — this is a classic ETL auditing
     practice.
   - Drops exact duplicate rows.

3. **Load** (`get_db_connection`, `setup_database_and_table`, `load_data`) —
   - Connects to MySQL (credentials only in the git-ignored `config.py`).
   - Creates the database and table if they don't exist (idempotent).
   - Bulk-inserts all cleaned rows using `executemany`, with commit/rollback
     around the transaction and the connection always closed in a `finally`
     block.

4. **Analyze** (`sql/analysis.sql`) — Once enough snapshots exist, SQL is
   used to answer real analytical questions: current market state, trends
   over time, and simple reporting — which is exactly what a Data Engineer
   is expected to enable for downstream consumers (analysts, dashboards).

---

## 7. Error Handling Summary

| Failure scenario            | Where handled                          | Behavior |
|------------------------------|-----------------------------------------|----------|
| API unreachable / no internet | `extract_data` (`ConnectionError`)     | Logged, pipeline stops gracefully |
| API request timeout          | `extract_data` (`Timeout`)              | Logged, pipeline stops gracefully |
| HTTP 4xx/5xx response         | `extract_data` (`raise_for_status`)     | Logged with status code |
| Invalid / malformed JSON      | `extract_data` (`JSONDecodeError`)      | Logged, pipeline stops |
| Missing required fields       | `transform_data`                        | Record dropped with a warning; pipeline continues with remaining valid records |
| MySQL connection failure      | `get_db_connection`                     | Logged, pipeline stops before attempting inserts |
| Insert/commit failure         | `load_data`                             | Transaction rolled back, connection still closed safely |

No step ever lets an unhandled exception crash the whole script silently —
every stage logs a clear message describing what went wrong and where.

---

## 8. Likely Interview Questions & Answers

**Q1. Why did you choose CoinGecko over a weather or exchange-rate API?**
A: It needs no authentication, has generous free-tier limits, and returns
rich numeric data (price, market cap, volume, rank, 24h change) that makes
the SQL analysis (grouping, trends, aggregates) much more meaningful than a
single-value API would.

**Q2. Walk me through your ETL pipeline end to end.**
A: Extract calls the REST API over HTTP GET and gets JSON back; Transform
loads it into pandas, validates types, handles missing values, standardizes
fields, and timestamps the collection; Load creates the MySQL schema if
needed and inserts the cleaned records; SQL scripts then run analytics on
top of the accumulated data.

**Q3. How do you handle missing or malformed data from the API?**
A: If an essential identifier (id/symbol/name) is missing, that record is
dropped with a logged warning so it doesn't corrupt downstream data.
Missing numeric fields get a safe default instead of crashing the whole
run. All JSON parsing is wrapped in try/except for `JSONDecodeError`.

**Q4. Why use pandas instead of just looping over the JSON in plain Python?**
A: pandas gives fast, vectorized type coercion (`pd.to_numeric`), easy
missing-value handling (`fillna`), simple deduplication
(`drop_duplicates`), and a natural bridge to tabular/SQL-shaped data —
which mirrors how real-world ETL transformation steps are usually written.

**Q5. Why did you add both `last_updated` and `collected_at` timestamps?**
A: `last_updated` is the API's own claim about when the price changed;
`collected_at` is when *my pipeline* actually pulled it. They can differ,
and keeping both is standard ETL practice for auditing and debugging data
freshness issues.

**Q6. How would you prevent duplicate data if you run the pipeline multiple
times per second?**
A: The table has a `UNIQUE KEY (coin_id, collected_at)` constraint, and the
DataFrame itself is deduplicated on `id` before insert. For stricter
idempotency I'd add an `INSERT ... ON DUPLICATE KEY UPDATE` or a
pre-insert existence check.

**Q7. How would you scale this to run automatically every hour?**
A: At a fresher level, a simple OS-level cron job (Linux) or Task Scheduler
(Windows) calling `python src/pipeline.py` on a schedule. At a larger scale
you'd reach for an orchestrator like Airflow, but that's intentionally out
of scope for this project.

**Q8. How do you keep your database credentials secure?**
A: Credentials live only in `config/config.py`, which is excluded via
`.gitignore` and never committed. The repo only ships
`config.example.py` with placeholder values, so nothing sensitive is ever
exposed in version control.

**Q9. What SQL concepts does this project demonstrate?**
A: Aggregate functions (`COUNT`, `MIN`, `MAX`, `AVG`), `GROUP BY` with a
`CASE`-based bucketing expression, subqueries (`WHERE collected_at =
(SELECT MAX(...))`), and a self-join pattern to fetch the latest row per
group — all common real-world SQL analyst/engineer patterns.

**Q10. What would you improve if you had more time?**
A: Add retry-with-backoff for transient API failures, batch/chunked inserts
for very large payloads, a `.env` file with `python-dotenv` instead of a
plain config module, unit tests for the transform logic, and a lightweight
scheduler (cron) to run it continuously and build a real time-series
history.

---

## 9. 60-Second Interview Pitch

> "I built a small end-to-end ETL pipeline in Python. It calls a public
> REST API — CoinGecko — over HTTP to pull live cryptocurrency market
> data as JSON, without needing any API key. I extract only the fields I
> need, load them into a pandas DataFrame, and run validation there:
> handling missing fields, enforcing correct data types, standardizing
> text, and stamping each row with when it was collected. That clean data
> gets loaded into a MySQL table that I create programmatically, using
> parameterized inserts so it's safe from SQL injection. On top of that, I
> wrote SQL queries that do real analysis — counts, min/max, averages,
> grouping coins into market-cap tiers, and finding the top gainers in the
> latest snapshot. Every stage — the API call, the JSON parsing, the
> database connection — has explicit error handling, so a network hiccup
> or a malformed record doesn't crash the whole pipeline. It's small
> enough to explain in a few minutes, but it touches almost everything a
> Data Engineer does day to day: extracting from an API, transforming and
> validating data, loading it into a relational database, and writing SQL
> to turn it into insight."

---

## 10. Sample Interaction (what happens when you run it)

```
2026-09-05 10:00:01 | INFO     | === Pipeline started ===
2026-09-05 10:00:01 | INFO     | Requesting data from https://api.coingecko.com/api/v3/coins/markets
2026-09-05 10:00:02 | INFO     | Received 25 records from API
2026-09-05 10:00:02 | INFO     | Transformed data into DataFrame with 25 rows
2026-09-05 10:00:02 | INFO     | Database 'crypto_pipeline' and table 'crypto_prices' are ready
2026-09-05 10:00:02 | INFO     | Inserted 25 record(s) into crypto_prices
2026-09-05 10:00:02 | INFO     | MySQL connection closed
2026-09-05 10:00:02 | INFO     | === Pipeline finished ===
```
